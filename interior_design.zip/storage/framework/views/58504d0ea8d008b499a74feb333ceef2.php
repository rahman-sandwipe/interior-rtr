<footer class="footer-light">
    <div class="container relative z-1000">
        <div class="row gx-5">
            <div class="col-lg-4 col-sm-6">
                <img src="<?php echo e(asset($settings->Logo)); ?>" alt="<?php echo e($settings->Title); ?>" width="170">
                <div class="spacer-20"></div>
                <p><?php echo $settings->Description; ?></p>
                
            </div>
            <div class="col-lg-4 col-sm-12 order-lg-1 order-sm-2">
                <div class="social-icons mb-sm-30">
                    <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="#"><i class="fa-brands fa-x-twitter"></i></a>
                    <a href="#"><i class="fa-brands fa-discord"></i></a>
                    <a href="#"><i class="fa-brands fa-tiktok"></i></a>
                    <a href="#"><i class="fa-brands fa-youtube"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-sm-6 order-lg-2 order-sm-1">
                <div class="widget">
                    <div class="fw-bold text-dark">
                        <i class="icofont-location-pin me-2 id-color"></i>
                        <span>Office Location</span>
                    </div>
                    <span>100 S Main St, Los Angeles, CA</span>

                    <div class="spacer-20"></div>

                    <div class="fw-bold text-dark">
                        <i class="icofont-envelope me-2 id-color"></i>
                        <span>Send a Message</span>
                    </div>
                    <span>contact@mindthera.com</span>
                </div>
            </div>
        </div>
    </div>
    <div class="subfooter relative z-1000">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="de-flex">
                        <div class="de-flex-col">
                            <span class="pl-1">Copyright 2024 - Designed by</span> <a href="#"> MOREXHUB TECH</a>
                        </div>
                        <ul class="menu-simple">
                            <li><a href="#">Terms &amp; Conditions</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <img src="<?php echo e(asset('front/images/misc/flowers-crop-3.webp')); ?>" class="w-20 absolute top-0 end-0 sw-anim" alt="">
</footer><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/front/inc/footer.blade.php ENDPATH**/ ?>