<head>
    <title><?php echo $__env->yieldContent('title'); ?> :: <?php echo e($settings->Title); ?> - <?php echo e($settings->Tagline); ?></title>
    <link rel="icon" href="<?php echo e(asset($settings->Favicon)); ?>" type="image/gif" sizes="16x16">
    <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
    <meta content="width=device-width, initial-scale=1.0" name="viewport" >
    <meta content="<?php echo e($settings->Tags); ?>" name="keywords" >
    <meta content="<?php echo e($settings->Description); ?>" name="description" >
    <meta content="<?php echo e($settings->Author); ?>" name="author" >
    <meta content="<?php echo e($settings->Developer); ?>" name="developer" >
    <!-- CSS Files
    ================================================== -->
    <link href="<?php echo e(asset('front/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" id="bootstrap">
    <link href="<?php echo e(asset('front/css/plugins.css')); ?>" rel="stylesheet" type="text/css" >
    <link href="<?php echo e(asset('front/css/swiper.css')); ?>" rel="stylesheet" type="text/css" >
    <link href="<?php echo e(asset('front/css/style.css')); ?>" rel="stylesheet" type="text/css" >
    <link href="<?php echo e(asset('front/css/coloring.css')); ?>" rel="stylesheet" type="text/css" >
    <!-- color scheme -->
    <link id="colors" href="<?php echo e(asset('front/css/colors/scheme-01.css')); ?>" rel="stylesheet" type="text/css" >
</head><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/components/front-header-css.blade.php ENDPATH**/ ?>