<div class="page-header">
    <div class="row">
        <div class="col-sm-12">
            <h3 class="page-title">Settings</h3>
            <ul class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Settings</li>
            </ul>
        </div>
    </div>
</div><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/settings/page-header.blade.php ENDPATH**/ ?>