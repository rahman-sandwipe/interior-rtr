<div class="card mb-0">
    <div class="card-body">
        <!-- Web Info -->
        <h3 class="card-title"><span>Web Informations</span>
            <a href="#" class="edit-icon" data-toggle="modal" data-target="#web_info">
                <i class="fa fa-pencil"></i>
            </a>
        </h3>
        <!-- Views -->
        <div class="row">
            <div class="col-md-12">
                <ul class="personal-info">
                    <!-- Title -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Title:-')); ?></div>
                        <div class="text"><?php echo e($getData->Title); ?></div>
                    </li>
                    <!-- Tagline -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Tagline:-')); ?></div>
                        <div class="text"><?php echo e($getData->Tagline); ?></div>
                    </li>
                    <!-- Favicon -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Favicon:-')); ?></div>
                        <div class="text">
                            <img src="<?php echo e(asset($getData->Favicon)); ?>" alt="Favicon" width="70">
                        </div>
                    </li>
                    <!-- Logo -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Logo:-')); ?></div>
                        <div class="text">
                            <img src="<?php echo e(asset($getData->Logo)); ?>" alt="Logo" width="220">
                        </div>
                    </li>
                    <!-- Dark Logo -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Dark Logo:-')); ?></div>
                        <div class="text bg-dark">
                            <img src="<?php echo e(asset($getData->DarkLogo)); ?>" alt="DarkLogo" width="220">
                        </div>
                    </li>
                    <!-- Author Name -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Author Name:-')); ?></div>
                        <div class="text"><?php echo e($getData->Author); ?></div>
                    </li>
                    <!-- Author Number -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Author Number:-')); ?></div>
                        <div class="text"><?php echo e($getData->AuthorNumber); ?></div>
                    </li>
                    <!-- Author Email -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Author Email:-')); ?></div>
                        <div class="text"><?php echo e($getData->AuthorEmail); ?></div>
                    </li>
                    <!-- Developer -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Developer:-')); ?></div>
                        <div class="text"><?php echo e($getData->Developer); ?></div>
                    </li>
                    <!-- Developer Number -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Developer Number:-')); ?></div>
                        <div class="text"><?php echo e($getData->DeveloperNumber); ?></div>
                    </li>
                    <!-- Developer Email -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Developer Email:-')); ?></div>
                        <div class="text"><?php echo e($getData->Tagline); ?></div>
                    </li>
                    <!-- Meta Tags -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Tags:-')); ?></div>
                        <div class="text"><?php echo e($getData->Tags); ?></div>
                    </li>
                    <!-- Meta Description -->
                    <li class="border p-2">
                        <div class="title"><?php echo e(__('Description:-')); ?></div>
                        <div class="text"><?php echo e($getData->Description); ?></div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/settings/page-wrapper.blade.php ENDPATH**/ ?>