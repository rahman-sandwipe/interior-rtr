
<?php $__env->startSection('title'); ?> Abouts <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Wrapper -->
<div class="page-wrapper">
    <!-- Page Content -->
    <div class="content container-fluid">
        <!-- Page Header -->
        <?php echo $__env->make('back.abouts.page-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /Page Header -->
        
        <?php echo $__env->make('back.abouts.page-wrapper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- /Page Content -->
</div>
<!-- /Page Wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            // Display image preview
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        var html = '<div class="preview-image border-gray-100"><img src="' + e.target.result + '"></div>';
                        $('.preview-images-zone').append(html);
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }
            // Trigger image preview when file input changes
            $("input[name='img']").change(function() {
                readURL(this);
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/pages/abouts.blade.php ENDPATH**/ ?>