<div class="table-responsive">
        
    <table class="table table-bordered mb-0">
        <thead>
            <tr>
                <th class="text-center"># / Service ID</th>
                <th class="text-center">Image</th>
                <th class="text-center">Title</th>
                <th class="text-center">Description</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($services) == 0): ?>
            <tr>
                <td colspan="5" class="text-center">No Services Found</td>
            </tr>
            <?php else: ?>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($service->id); ?> / <?php echo e($service->service_id); ?></th>
                    <td><img src="<?php echo e(asset($service->img)); ?>" alt="<?php echo e($service->title); ?>" width="100"></td>
                    <td><?php echo e($service->title); ?></td>
                    <td><?php echo $service->description; ?></td>
                    <td>
                        <button type="button" class="btn btn-primary waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg-<?php echo e($service->id); ?>">Edit</button>
                        <a href="<?php echo e(route('service.destroy', $service->id)); ?>" class="btn btn-danger waves-effect waves-light mt-1">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/include/backend/service/service-list.blade.php ENDPATH**/ ?>