<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <meta name="robots" content="index, follow">
        <title><?php echo $__env->yieldContent('title'); ?></title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" href="" type="image/x-icon">

		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('back/css/bootstrap.min.css')); ?>">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('back/css/font-awesome.min.css')); ?>">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('back/css/style.css')); ?>">
		
		<!-- HTML5 shim and Respond.js') }} IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="<?php echo e(asset('back/js/html5shiv.min.js')); ?>"></script>
			<script src="<?php echo e(asset('back/js/respond.min.js')); ?>"></script>
		<![endif]-->
    </head>
    <body class="account-page">
		<!-- Main Wrapper -->
        <div class="main-wrapper">
            <div class="account-content">
                <div class="container">
                    <div class="account-box">
                        <!-- Account Logo -->
                        <div class="account-logo">
                            <a href="<?php echo e(route('home')); ?>">
                                <img src="" alt="<?php echo e(__('Logo')); ?>">
                            </a>
                        </div>
                        <main>
                            <?php echo $__env->yieldContent('content'); ?>
                        </main>
                    </div>
                </div>
            </div>
        </div>
		<!-- /Main Wrapper -->
        <script src="<?php echo e(asset('back/js/jquery-3.5.1.min.js')); ?>"></script>
		<!-- Bootstrap Core JS -->
        <script src="<?php echo e(asset('back/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('back/js/bootstrap.min.js')); ?>"></script>
    </body>
</html><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/auth/master.blade.php ENDPATH**/ ?>