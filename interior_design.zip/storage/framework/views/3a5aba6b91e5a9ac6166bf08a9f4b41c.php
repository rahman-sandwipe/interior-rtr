
<?php $__env->startSection('title'); ?> Settings <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Wrapper -->
<div class="page-wrapper">
    <!-- Page Content -->
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Users</h3>
                </div>
                <div class="col-auto float-right ml-auto">
                    <a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_user">
                        <i class="fa fa-plus"></i> Add User
                    </a>
                </div>
            </div>
        </div>

        <!-- /Page Wrapper -->
        <?php echo $__env->make('back.users.page-wrapper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- /Page Content -->
    
    
    <!-- Add User Modal -->
    <?php echo $__env->make('back.users.add-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /Modify User Modal -->
    <?php echo $__env->make('back.users.modify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Delete User Modal -->
    <?php echo $__env->make('back.users.delete-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/pages/users.blade.php ENDPATH**/ ?>