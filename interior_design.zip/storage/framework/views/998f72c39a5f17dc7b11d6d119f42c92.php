<div class="card mb-0">
    <div class="card-body">
        <form action="<?php echo e(route('abouts.update')); ?>" method="POST" class="row" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <!-- ==========  title ========== -->
            <div class="col-sm-12">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input name="title" value="<?php echo e($getData->title); ?>" id="title" class="form-control" type="text" required>
                </div>
            </div>
            <!-- ========== description ========== -->
            <div class="col-sm-12">
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" id="description" rows="2" class="form-control summernote" placeholder="Enter here..."><?php echo $getData->description; ?></textarea>
                </div>
            </div>
            <!-- ========== Our Mission ========== -->
            <div class="col-sm-12">
                <div class="form-group">
                    <label for="mission">Our Mission</label>
                    <textarea name="mission" id="mission" rows="2" class="form-control summernote" placeholder="Enter here..."><?php echo $getData->mission; ?></textarea>
                </div>
            </div>
            <!-- ========== Our Vision ========== -->
            <div class="col-sm-12">
                <div class="form-group">
                    <label for="vision">Our Vision</label>
                    <textarea name="vision" id="h_desc" rows="2" class="form-control summernote" placeholder="Enter here..."><?php echo $getData->vision; ?></textarea>
                </div>
            </div>
            <!-- ========== Video ========== -->
            <div class="col-sm-9">
                <div class="form-group">
                    <label for="video">Video [EMBED CODE]</label>
                    <input name="video" value="<?php echo e($getData->video); ?>" id="video" class="form-control" type="text">
                </div>
            </div>
            <div class="col-sm-3">
                <!-- this is Video preview -->
                <iframe width="200" height="125" src="<?php echo e(asset('https://www.youtube.com/embed/'.$getData->video)); ?>" allowfullscreen></iframe>
                
            </div>
            <!-- ========== IMG ========== -->
            <div class="col-sm-9">
                <div class="form-group">
                    <label for="img">IMAGE</label>
                    <input name="img" id="img" class="form-control" type="file">
                </div>
            </div>
            <div class="col-sm-1">
                <!-- this is article thumb preview -->
                <div class="preview-images-zone1"></div>
            </div>
            <div class="col-sm-2">
                <img src="<?php echo e(asset($getData->img)); ?>" width="100" alt="img">
            </div>
            <div class="col-sm-12">
                <button type="submit" class="btn btn-info btn-block"><i class="fa fa-save"></i> SUBMIT</button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/abouts/page-wrapper.blade.php ENDPATH**/ ?>