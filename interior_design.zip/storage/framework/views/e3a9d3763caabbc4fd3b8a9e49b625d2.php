


<!-- Search Filter -->

<div class="row staff-grid-row">
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
        <div class="profile-widget">
            <div class="profile-img">
                <a href="<?php echo e(route('user.profile.view',$user->auth_id)); ?>" class="avatar">
                    <img src="<?php echo e(asset($user->avatar)); ?>" alt="<?php echo e($user->name); ?>">
                </a>
            </div>
            <div class="dropdown profile-action">
                <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_user">
                        <i class="fa fa-pencil m-r-5"></i>
                        <span>Edit</span>
                    </a>
                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_user">
                        <i class="fa fa-trash-o m-r-5"></i>
                        <span>Delete</span>
                    </a>
                </div>
            </div>
            <h4 class="user-name m-t-10 mb-0 text-ellipsis">
                <a href="profile.html"><?php echo e($user->name); ?></a>
            </h4>
            <div class="small text-muted"><?php echo e($user->auth_id); ?></div>
            <div class="small text-muted"><?php echo e($user->designation); ?></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<!-- /Page Content --><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/users/page-wrapper.blade.php ENDPATH**/ ?>