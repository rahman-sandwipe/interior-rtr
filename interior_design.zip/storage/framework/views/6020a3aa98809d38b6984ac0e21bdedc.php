
<div id="edit_banner" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modify this banner</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('banner.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <input type="text" name="ban_id" id="ban_id">
                        <!-- title img description btn_link -->
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="title">Title <span class="text-danger">*</span></label>
                                <input name="title" id="title" class="form-control" type="text" required>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="btn_link">Button Link</label>
                                <input name="btn_link" id="btn_link" class="form-control" type="text">
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="description">Description <span class="text-danger">*</span></label>
                                <textarea name="description" id="description" rows="4" class="form-control summernote" placeholder="Enter your message here"></textarea>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="img">IMAGE </label>
                                <input name="img" id="img" class="form-control" type="file">
                            </div>
                        </div>
                    </div>
                    
                    <div class="submit-section">
                        <button class="btn btn-primary submit-btn">UPDATE</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/banners/edit-form.blade.php ENDPATH**/ ?>