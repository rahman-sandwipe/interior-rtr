
<?php $__env->startSection('title'); ?> Articles <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="content" class="no-top no-bottom">
    <div id="top"></div>
    <!-- section begin -->
    <section id="de-subheader" class="mt-sm-60 pt20 pb20 bg-gradient-45-deg text-light">
        <div class="container relative z-index-1000">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h3 class="mb-0">Blog</h3>
                </div>

                <div class="col-lg-6 text-lg-end">
                    <ul class="crumb">
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Blog</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- section close -->

    <section>
        <div class="container">
            <div class="row g-4 gy-5">
                <div class="col-lg-4 col-md-6 mb10">
                    <div class="rounded-20px">
                        <div class="post-image rounded-10px">
                            <div class="d-tagline">
                                <span>tips &amp; tricks</span>
                            </div>
                            <img alt="" src="images/news/1.webp" class="lazy">
                        </div>
                        <div class="pt-2 h-100">
                            <h4><a class="text-dark" href="blog-single.html">The Power of Positive Thinking</a></h4>
                            <p class="mb-3">Dolore officia sint incididunt non excepteur ea mollit commodo ut enim reprehenderit cupidatat labore ad laborum consectetur consequat...</p>
                            <div class="relative bg-grey p-1 px-3 rounded-10px">
                                <img src="images/testimonial/1.jpg" class="w-20px me-2 circle" alt="">
                                <div class="d-inline fs-14 fw-bold me-3">Brunilda Doniger</div>
                                <div class="d-inline fs-14 fw-600"><i class="icofont-ui-calendar id-color me-2"></i>18 Mar 2024</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 mb10">
                    <div class="rounded-20px">
                        <div class="post-image rounded-10px">
                            <div class="d-tagline">
                                <span>tips &amp; tricks</span>
                            </div>
                            <img alt="" src="images/news/2.webp" class="lazy">
                        </div>
                        <div class="pt-2 h-100">
                            <h4><a class="text-dark" href="blog-single.html">Understanding the Roots of Anxiety</a></h4>
                            <p class="mb-3">Dolore officia sint incididunt non excepteur ea mollit commodo ut enim reprehenderit cupidatat labore ad laborum consectetur consequat...</p>
                            <div class="relative bg-grey p-1 px-3 rounded-10px">
                                <img src="images/testimonial/1.jpg" class="w-20px me-2 circle" alt="">
                                <div class="d-inline fs-14 fw-bold me-3">Brunilda Doniger</div>
                                <div class="d-inline fs-14 fw-600"><i class="icofont-ui-calendar id-color me-2"></i>18 Mar 2024</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 mb10">
                    <div class="rounded-20px">
                        <div class="post-image rounded-10px">
                            <div class="d-tagline">
                                <span>tips &amp; tricks</span>
                            </div>
                            <img alt="" src="images/news/3.webp" class="lazy">
                        </div>
                        <div class="pt-2 h-100">
                            <h4><a class="text-dark" href="blog-single.html">The Psychology of Procrastination</a></h4>
                            <p class="mb-3">Dolore officia sint incididunt non excepteur ea mollit commodo ut enim reprehenderit cupidatat labore ad laborum consectetur consequat...</p>
                            <div class="relative bg-grey p-1 px-3 rounded-10px">
                                <img src="images/testimonial/1.jpg" class="w-20px me-2 circle" alt="">
                                <div class="d-inline fs-14 fw-bold me-3">Brunilda Doniger</div>
                                <div class="d-inline fs-14 fw-600"><i class="icofont-ui-calendar id-color me-2"></i>18 Mar 2024</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 mb10">
                    <div class="rounded-20px">
                        <div class="post-image rounded-10px">
                            <div class="d-tagline">
                                <span>tips &amp; tricks</span>
                            </div>
                            <img alt="" src="images/news/4.webp" class="lazy">
                        </div>
                        <div class="pt-2 h-100">
                            <h4><a class="text-dark" href="blog-single.html">Stress Management Techniques</a></h4>
                            <p class="mb-3">Dolore officia sint incididunt non excepteur ea mollit commodo ut enim reprehenderit cupidatat labore ad laborum consectetur consequat...</p>
                            <div class="relative bg-grey p-1 px-3 rounded-10px">
                                <img src="images/testimonial/1.jpg" class="w-20px me-2 circle" alt="">
                                <div class="d-inline fs-14 fw-bold me-3">Brunilda Doniger</div>
                                <div class="d-inline fs-14 fw-600"><i class="icofont-ui-calendar id-color me-2"></i>18 Mar 2024</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 mb10">
                    <div class="rounded-20px">
                        <div class="post-image rounded-10px">
                            <div class="d-tagline">
                                <span>tips &amp; tricks</span>
                            </div>
                            <img alt="" src="images/news/5.webp" class="lazy">
                        </div>
                        <div class="pt-2 h-100">
                            <h4><a class="text-dark" href="blog-single.html">The Psychology of Resilience</a></h4>
                            <p class="mb-3">Dolore officia sint incididunt non excepteur ea mollit commodo ut enim reprehenderit cupidatat labore ad laborum consectetur consequat...</p>
                            <div class="relative bg-grey p-1 px-3 rounded-10px">
                                <img src="images/testimonial/1.jpg" class="w-20px me-2 circle" alt="">
                                <div class="d-inline fs-14 fw-bold me-3">Brunilda Doniger</div>
                                <div class="d-inline fs-14 fw-600"><i class="icofont-ui-calendar id-color me-2"></i>18 Mar 2024</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 mb10">
                    <div class="rounded-20px">
                        <div class="post-image rounded-10px">
                            <div class="d-tagline">
                                <span>tips &amp; tricks</span>
                            </div>
                            <img alt="" src="images/news/6.webp" class="lazy">
                        </div>
                        <div class="pt-2 h-100">
                            <h4><a class="text-dark" href="blog-single.html">The Secrets to a Fulfilling Life</a></h4>
                            <p class="mb-3">Dolore officia sint incididunt non excepteur ea mollit commodo ut enim reprehenderit cupidatat labore ad laborum consectetur consequat...</p>
                            <div class="relative bg-grey p-1 px-3 rounded-10px">
                                <img src="images/testimonial/1.jpg" class="w-20px me-2 circle" alt="">
                                <div class="d-inline fs-14 fw-bold me-3">Brunilda Doniger</div>
                                <div class="d-inline fs-14 fw-600"><i class="icofont-ui-calendar id-color me-2"></i>18 Mar 2024</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/front/pages/blogs.blade.php ENDPATH**/ ?>