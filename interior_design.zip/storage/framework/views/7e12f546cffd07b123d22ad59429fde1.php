
<?php $__env->startSection('title'); ?> Banners <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Wrapper -->
<div class="page-wrapper">
    <!-- Page Content -->
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Banners</h3>
                </div>
                <div class="col-auto float-right ml-auto">
                    <a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_banner">
                        <i class="fa fa-plus"></i> 
                        <span>INSERT</span>
                    </a>
                </div>
            </div>
        </div>
        <?php echo $__env->make('back.banners.page-wrapper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- /Page Content -->
    
    
    <!-- Add User Modal -->
    <?php echo $__env->make('back.banners.add-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /Modify User Modal -->
    <div id="edit_banner" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modify this banner</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('banner.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <input type="text" name="ban_id" id="ban_id">
                            <!-- title img description btn_link -->
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="title">Title <span class="text-danger">*</span></label>
                                    <input name="title" id="title" class="form-control" type="text" required>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="btn_link">Button Link</label>
                                    <input name="btn_link" id="btn_link" class="form-control" type="text">
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="description">Description <span class="text-danger">*</span></label>
                                    <textarea name="description" id="description" rows="4" class="form-control summernote" placeholder="Enter your message here"></textarea>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="img">IMAGE </label>
                                    <input name="img" id="img" class="form-control" type="file">
                                </div>
                            </div>
                        </div>
                        
                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn">UPDATE</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Delete User Modal -->
    <?php echo $__env->make('back.banners.delete-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $(document).on('click', '.editbtn', function() {
            var ban_id = $(this).val();
            $('#edit_banner').modal('show');
            $.ajax({
                type: "get",
                url: "/admin/banner/edit/"+ban_id,
                success: function(response) {
                    $('#title').val(response.banner.title);
                    $('#btn_link').val(response.banner.btn_link);
                    $('#description').val(response.banner.description);
                    $('#ban_id').val(ban_id);
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/banners/banners.blade.php ENDPATH**/ ?>