
<?php $__env->startSection('title'); ?> <?php echo e(__('Login Session')); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- /Account Logo -->
<div class="account-wrapper">
    <h3 class="account-title"><?php echo e(__('Login')); ?></h3>
    
    
    <!-- Account Form -->
    <form action="<?php echo e(route('login.post')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="email"><?php echo e(__('Email Address')); ?></label>
            <input name="email" id="email" class="form-control" type="text">
        </div>
        <div class="form-group">
            <div class="row">
                <div class="col">
                    <label for="password"><?php echo e(__('Password')); ?></label>
                </div>
                <div class="col-auto">
                    <a class="text-muted" href="<?php echo e(route('forget.password.get')); ?>">
                        <?php echo e(__('Forgot password?')); ?>

                    </a>
                </div>
            </div>
            <input name="password" id="password" class="form-control" type="password">
        </div>

        <div class="form-group">
            <div class="checkbox">
                <label>
                    <input type="checkbox" name="remember_me"> <?php echo e(__('Remember Me')); ?>

                </label>
            </div>
        </div>
        <div class="form-group text-center">
            <button class="btn btn-primary account-btn" type="submit"><?php echo e(__('Login')); ?></button>
        </div>
    </form>
    <!-- /Account Form -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.auth.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/auth/login.blade.php ENDPATH**/ ?>