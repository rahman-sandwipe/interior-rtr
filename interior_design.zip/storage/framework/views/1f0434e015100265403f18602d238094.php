<header class="scroll-light">
    <div id="topbar">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between xs-hide">
                        <div class="header-widget d-flex">
                            <div class="topbar-widget"><a href="#"><i class="icofont-location-pin"></i>100 S Main St, Los Angeles, CA</a></div>                                    
                            <div class="topbar-widget"><a href="#"><i class="icofont-clock-time"></i><span>Mon - Sat: 8AM - 9PM</span><span class="ms-3">Sunday: 10AM - 8PM</a></div>
                            <div class="topbar-widget"><a href="#"><i class="icofont-envelope"></i>contact@mindthera.com</a></div>
                        </div>
                        
                        <div class="social-icons">
                            <a href="#"><i class="fa-brands fa-facebook fa-lg"></i></a>
                            <a href="#"><i class="fa-brands fa-x-twitter fa-lg"></i></a>
                            <a href="#"><i class="fa-brands fa-youtube fa-lg"></i></a>
                            <a href="#"><i class="fa-brands fa-pinterest fa-lg"></i></a>
                            <a href="#"><i class="fa-brands fa-instagram fa-lg"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="de-flex sm-pt10">
                    <div class="de-flex-col">
                        <!-- logo begin -->
                        <div id="logo">
                            <a href="<?php echo e(route('home')); ?>">
                                <img class="logo-main" src="<?php echo e(asset($settings->DarkLogo)); ?>" alt="Logo" >
                                <img class="logo-scroll" src="<?php echo e(asset($settings->Logo)); ?>" alt="Logo" >
                                <img class="logo-mobile" src="<?php echo e(asset($settings->Logo)); ?>" alt="Logo" >
                            </a>
                        </div>
                        <!-- logo close -->
                    </div>
                    <div class="de-flex-col header-col-mid">
                        <ul id="mainmenu">
                            <li>
                                <a class="menu-item" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                            </li>
                            <li>
                                <a class="menu-item" href="#"><?php echo e(__('Services')); ?></a>
                            </li>
                            <li>
                                <a class="menu-item" href="about.html"><?php echo e(__('About Us')); ?></a>
                            </li>
                            <li>
                                <a class="menu-item" href="study-case.html"><?php echo e(__('Study Case')); ?></a>
                            </li>
                            <li>
                                <a class="menu-item" href="blog.html"><?php echo e(__('Blog')); ?></a>
                            </li>
                            <li>
                                <a class="menu-item" href="contact.html"><?php echo e(__('Contact')); ?></a>
                            </li>
                        </ul>
                    </div>
                    <div class="de-flex-col">
                        <div class="menu_side_area">
                            <div class="h-phone xs-hide">
                                <i class="icofont-headphone-alt"></i>
                                <span>Need Help?</span>+929 333 9296
                            </div>                                    
                            <a href="appointment.html" class="btn-main d-xl-block d-md-none">Make Appointment</a>
                            <span id="menu-btn"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/components/front-header.blade.php ENDPATH**/ ?>