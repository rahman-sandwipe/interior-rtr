
<?php $__env->startSection('title'); ?> Abouts <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <!-- Start Content-->
    <div class="container-fluid">
        <?php echo $__env->make('include.backend.abouts.title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- end page title --> 

        <div class="card-box">
            <?php echo $__env->make('include.backend.abouts.abouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- end abouts -->
        </div> <!-- end card-box -->
    </div> <!-- end container-fluid -->
</div> <!-- end content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        // Display image preview
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    var html = '<div class="preview-image border"><img width="100" src="' + e.target.result + '"></div>';
                    $('.preview').append(html);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        // Trigger image preview when file input changes
        $("input[name='image']").change(function() {
            readURL(this);
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/pages/backend/abouts.blade.php ENDPATH**/ ?>