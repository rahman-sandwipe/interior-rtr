
<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li>
                    <a href="<?php echo e(route('admin.dashboard')); ?>">
                        <i class="fa fa-dashboard" aria-hidden="true"></i>
                        <span> Dashboard</span>
                    </a>
                </li>
                <li class="submenu">
                    <a href="#">
                        <i class="fa fa-cog" aria-hidden="true"></i>
                        <span> Settings</span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(route('index.settings')); ?>">Settings</a></li>
                        <li><a href="file-manager.html">File Manager</a></li>
                    </ul>
                </li>
                
                <li class="submenu">
                    <a href="#">
                        <i class="fa fa-book" aria-hidden="true"></i>
                        <span> Pages</span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(route('banner.index')); ?>">Banners</a></li>
                        <li><a href="<?php echo e(route('abouts.index')); ?>">Abouts</a></li>
                    </ul>
                </li>
                <li> 
                    <a href="<?php echo e(route('all.users')); ?>">
                        <i class="la la-users"></i>
                        <span>Clients</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/inc/sidebar.blade.php ENDPATH**/ ?>