<!-- Experience Modal -->
<div id="web_info" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Informations Modify</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('update.settings')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- Title -->
                    <div class="form-group">
                        <label for="Title">Title</label>
                        <input type="text" name="Title" id="Title" value="<?php echo e($getData->Title); ?>" class="form-control">
                    </div>
        
                    <!-- Tagline -->
                    <div class="form-group">
                        <label for="Tagline">Tagline</label>
                        <input type="text" name="Tagline" id="Tagline" value="<?php echo e($getData->Tagline); ?>" class="form-control">
                    </div>
        
                    <!-- Favicon -->
                    <div class="row">
                        <div class="col-md-10">
                            <div class="form-group">
                                <label for="Favicon">Favicon</label>
                                <input type="file" name="Favicon" id="Favicon" class="form-control" onchange="readURL(this);" />
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group border image-preview">
                                <img id="favView" src="http://placehold.it/100x80" alt="your image" />
                            </div>
                        </div>
                    </div>
        
                    <!-- Logo -->
                    <div class="row">
                        <div class="col-md-9">
                            <div class="form-group">
                                <label for="Logo">Logo</label>
                                <input type="file" name="Logo" id="Logo" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group border l-image-preview">
                                <img id="logoView" src="http://placehold.it/180" alt="your image" />
                            </div>
                        </div>
                    </div>
        
                    <!-- Dark Logo -->
                    <div class="row">
                        <div class="col-md-9">
                            <div class="form-group">
                                <label for="DarkLogo">Dark Logo</label>
                                <input type="file" name="DarkLogo" id="DarkLogo" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group border l-image-preview">
                                <img id="darkView" src="http://placehold.it/180" alt="your image" />
                            </div>
                        </div>
                    </div>
        
                    <!-- Author Name -->
                    <div class="form-group">
                        <label for="Author">Author Name</label>
                        <input type="text" name="Author" value="<?php echo e($getData->Author); ?>" id="Author" class="form-control">
                    </div>
        
                    <!-- Author Number -->
                    <div class="form-group">
                        <label for="AuthorNumber">Author Number</label>
                        <input type="text" name="AuthorNumber" value="<?php echo e($getData->AuthorNumber); ?>" id="AuthorNumber" class="form-control">
                    </div>
        
                    <!-- Author Email -->
                    <div class="form-group">
                        <label for="AuthorEmail">Author Email</label>
                        <input type="email" name="AuthorEmail" value="<?php echo e($getData->AuthorEmail); ?>" id="AuthorEmail" class="form-control">
                    </div>
                    
                    <!-- Developer -->
                    <div class="form-group">
                        <label for="Developer">Developer Name</label>
                        <input type="text" name="Developer" value="<?php echo e($getData->Developer); ?>" id="Developer" class="form-control">
                    </div>
        
                    <!-- Developer Number -->
                    <div class="form-group">
                        <label for="DeveloperNumber">Developer Number</label>
                        <input type="text" name="DeveloperNumber" value="<?php echo e($getData->DeveloperNumber); ?>" id="DeveloperNumber" class="form-control">
                    </div>
        
                    <!-- Developer Email -->
                    <div class="form-group">
                        <label for="DeveloperEmail">Developer Email</label>
                        <input type="email" name="DeveloperEmail" value="<?php echo e($getData->DeveloperEmail); ?>" id="DeveloperEmail" class="form-control">
                    </div>
                    <!-- Meta Tags -->
                    <div class="form-group">
                        <label for="Tags">Meta Tags</label>
                        <textarea name="Tags" id="Tags" class="form-control" rows="4"><?php echo $getData->Tags; ?></textarea>
                    </div>
                    <!-- Meta Description -->
                    <div class="form-group">
                        <label for="Description">Meta Description</label>
                        <textarea name="Description" id="Description" class="form-control" rows="5"><?php echo $getData->Description; ?></textarea>
                    </div>
                    
                    <div class="submit-section">
                        <button type="submit" class="btn btn-primary submit-btn">UPDATE</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /Experience Modal --><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/settings/web-info-form.blade.php ENDPATH**/ ?>