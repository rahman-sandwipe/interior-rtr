<div class="header">	
    <!-- Logo -->
    <div class="header-left">
        <a href="<?php echo e(route('dashboard')); ?>" class="logo">
            <img src="<?php echo e(asset($settings->Favicon)); ?>" width="50" height="40" alt="logo">
        </a>
    </div>
    <!-- /Logo -->
    
    <a id="toggle_btn" href="javascript:void(0);">
        <span class="bar-icon">
            <span></span>
            <span></span>
            <span></span>
        </span>
    </a>
    
    <!-- Header Title -->
    <div class="page-title-box">
        <h3><?php echo e($settings->Title); ?></h3>
    </div>
    <!-- /Header Title -->
    
    <a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa fa-bars"></i></a>
    
    <!-- Header Menu -->
    <ul class="nav user-menu">
    
        <!-- Search -->
        <li class="nav-item">
            <div class="top-nav-search">
                <a href="javascript:void(0);" class="responsive-search">
                    <i class="fa fa-search"></i>
               </a>
                <form action="search.html">
                    <input class="form-control" type="text" placeholder="Search here">
                    <button class="btn" type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
        </li>
        <!-- /Search -->
        
        <!-- Socials -->
        
        <li>
            <a href="<?php echo e(route('home')); ?>" class="p-2 ml-2 mr-2" target="_blank">
                <span class="bar-icon">
                    <i class="fa fa-home"></i>
                </span>
            </a>
        </li>

        <!-- Notifications -->
        <li class="nav-item dropdown">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                <i class="fa fa-bell-o"></i> <span class="badge badge-pill">3</span>
            </a>
            <div class="dropdown-menu notifications">
                <div class="topnav-dropdown-header">
                    <span class="notification-title">Notifications</span>
                    <a href="javascript:void(0)" class="clear-noti"> Clear All </a>
                </div>
                <div class="noti-content">
                    <ul class="notification-list">
                        <li class="notification-message">
                            <a href="activities.html">
                                <div class="media">
                                    <span class="avatar">
                                        <img alt="" src="<?php echo e(asset('back/img/profiles/avatar-02.jpg')); ?>">
                                    </span>
                                    <div class="media-body">
                                        <p class="noti-details"><span class="noti-title">John Doe</span> added new task <span class="noti-title">Patient appointment booking</span></p>
                                        <p class="noti-time"><span class="notification-time">4 mins ago</span></p>
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="topnav-dropdown-footer">
                    <a href="activities.html">View all Notifications</a>
                </div>
            </div>
        </li>
        <!-- /Notifications -->

        <li class="nav-item dropdown has-arrow main-drop">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                <span class="user-img">
                    <?php if(Auth::user()->avatar==NULL): ?>
                    <img src="<?php echo e(asset('back/img/profiles/avatar-21.jpg')); ?>" alt="">
                    <?php else: ?>
                    <img src="<?php echo e(asset(Auth::user()->avatar)); ?>" alt="Avatar">
                    <?php endif; ?>
                    <span class="status online"></span>
                </span>
                <span><?php echo e(Auth::user()->name); ?></span>
            </a>
            <div class="dropdown-menu mt-2">
                <a class="dropdown-item" href="<?php echo e(route('user.profile')); ?>">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <span>My Profile</span>
                </a>
                <a class="dropdown-item" href="<?php echo e(route('social.index')); ?>">
                    <i class="fa fa-share"></i>
                    <span>Socials Media</span>
                </a>
                <a class="dropdown-item" href="<?php echo e(route('admin.logout')); ?>">
                    <i class="fa fa-sign-out"></i>
                    <span>Logout</span>
                </a>
            </div>
        </li>
    </ul>
    <!-- /Header Menu -->
    
    <!-- Mobile Menu -->
    <div class="dropdown mobile-user-menu">
        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
        <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="profile.html">My Profile</a>
            <a class="dropdown-item" href="settings.html">Settings</a>
            <a class="dropdown-item" href="login.html">Logout</a>
        </div>
    </div>
    <!-- /Mobile Menu -->
</div>
<?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/inc/header.blade.php ENDPATH**/ ?>