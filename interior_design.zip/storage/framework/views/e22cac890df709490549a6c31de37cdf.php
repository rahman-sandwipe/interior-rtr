
<div class="row">
    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table table-striped custom-table datatable">
                <thead>
                    <tr>
                        <th>SL/BID</th>
                        <th>IMG</th>
                        <th>Title</th>
                        <th>Created Date</th>
                        <th class="text-right">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?> / <?php echo e($item->banner_id); ?></td>
                        <td>
                            <img src="<?php echo e(asset($item->img)); ?>" alt="<?php echo e($item->banner_id); ?>" width="70">
                        </td>
                        <td><?php echo e($item->title); ?></td>
                        <td><?php echo e(date('d M, Y', strtotime($item->created_at))); ?></td>
                        <td class="text-right">
                            <div>
                                <a href="<?php echo e($item->btn_link); ?>" class="btn btn-warning" target="_blank">
                                    <i class="fa fa-link" aria-hidden="true"></i>
                                    <span>View</span>
                                </a>
                                <button type="button" class="btn btn-info editbtn" value="<?php echo e($item->id); ?>">
                                    <i class="fa fa-pencil m-r-2"></i>
                                    <span>Edit</span>
                                </button>
                                <a class="btn btn-danger" href="#" data-toggle="modal" data-target="#delete_banner">
                                    <i class="fa fa-trash-o m-r-2"></i>
                                    <span>Delete</span>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- /Page Content --><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/banners/page-wrapper.blade.php ENDPATH**/ ?>