
<?php $__env->startSection('title'); ?> Services <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="content" class="no-top no-bottom">
    <div id="top"></div>
    <!-- section begin -->
    <section id="de-subheader" class="mt-sm-60 pt20 pb20 bg-gradient-45-deg text-light">
        <div class="container relative z-index-1000">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h3 class="mb-0">Our Services</h3>
                </div>

                <div class="col-lg-6 text-lg-end">
                    <ul class="crumb">
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Services</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- section close -->

    <section class="relative overflow-hidden">
        <img src="images/misc/flowers-crop-2.webp" class="w-30 absolute top-0 start-0 sw-anim" alt="">

        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3 text-center">
                    <div class="subtitle wow fadeInUp mb-3">Our Services</div>
                    <h2 class="wow fadeInUp" data-wow-delay=".2s">Therapist &amp; Treatments</h2>
                </div>
            </div>

            <div class="row g-5">
                <div class="col-lg-4 col-sm-6">
                    <div class="relative p-4 pb-0 text-center bg-grey mt-5 h-100 rounded-10px">
                        <div class="alt-font absolute end-0 pe-4 fw-bold fs-24 id-color">01</div>
                        <img src="images/services/1.webp" class="img-fluid circle mb-4 w-30 mt-50 shadow-soft wow scaleIn" alt="">
                        <h4>Individual Therapy</h4>
                        <p class="no-bottom">Sint tempor consequat ad commodo nostrud occaecat ad nulla labore esse culpa non dolore pariatur fugiat.</p>
                        <a class="btn-main btn-main btn-light-trans mt-3" href="service-single.html">Read More</a>
                    </div>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <div class="relative p-4 pb-0 text-center bg-grey mt-5 h-100 rounded-10px">
                        <div class="alt-font absolute end-0 pe-4 fw-bold fs-24 id-color">02</div>
                        <img src="images/services/2.webp" class="img-fluid circle mb-4 w-30 mt-50 shadow-soft wow scaleIn" alt="">
                        <h4>Couples Counseling</h4>
                        <p class="no-bottom">Sint tempor consequat ad commodo nostrud occaecat ad nulla labore esse culpa non dolore pariatur fugiat.</p>
                        <a class="btn-main btn-main btn-light-trans mt-3" href="service-single.html">Read More</a>
                    </div>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <div class="relative p-4 pb-0 text-center bg-grey mt-5 h-100 rounded-10px">
                        <div class="alt-font absolute end-0 pe-4 fw-bold fs-24 id-color">03</div>
                        <img src="images/services/3.webp" class="img-fluid circle mb-4 w-30 mt-50 shadow-soft wow scaleIn" alt="">
                        <h4>Career Counseling</h4>
                        <p class="no-bottom">Sint tempor consequat ad commodo nostrud occaecat ad nulla labore esse culpa non dolore pariatur fugiat.</p>
                        <a class="btn-main btn-main btn-light-trans mt-3" href="service-single.html">Read More</a>
                    </div>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <div class="relative p-4 pb-0 text-center bg-grey mt-5 h-100 rounded-10px">
                        <div class="alt-font absolute end-0 pe-4 fw-bold fs-24 id-color">04</div>
                        <img src="images/services/4.webp" class="img-fluid circle mb-4 w-30 mt-50 shadow-soft wow scaleIn" alt="">
                        <h4>Stress management</h4>
                        <p class="no-bottom">Sint tempor consequat ad commodo nostrud occaecat ad nulla labore esse culpa non dolore pariatur fugiat.</p>
                        <a class="btn-main btn-main btn-light-trans mt-3" href="service-single.html">Read More</a>
                    </div>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <div class="relative p-4 pb-0 text-center bg-grey mt-5 h-100 rounded-10px">
                        <div class="alt-font absolute end-0 pe-4 fw-bold fs-24 id-color">05</div>
                        <img src="images/services/5.webp" class="img-fluid circle mb-4 w-30 mt-50 shadow-soft wow scaleIn" alt="">
                        <h4>Anxiety Treatment</h4>
                        <p class="no-bottom">Sint tempor consequat ad commodo nostrud occaecat ad nulla labore esse culpa non dolore pariatur fugiat.</p>
                        <a class="btn-main btn-main btn-light-trans mt-3" href="service-single.html">Read More</a>
                    </div>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <div class="relative p-4 pb-0 text-center bg-grey mt-5 h-100 rounded-10px">
                        <div class="alt-font absolute end-0 pe-4 fw-bold fs-24 id-color">06</div>
                        <img src="images/services/6.webp" class="img-fluid circle mb-4 w-30 mt-50 shadow-soft wow scaleIn" alt="">
                        <h4>Depression Therapy</h4>
                        <p class="no-bottom">Sint tempor consequat ad commodo nostrud occaecat ad nulla labore esse culpa non dolore pariatur fugiat.</p>
                        <a class="btn-main btn-main btn-light-trans mt-3" href="service-single.html">Read More</a>
                    </div>
                </div>

                <div class="spacer-single"></div>
            </div>
        </div>
    </section>

    <section class="section-dark jarallax">
        <img src="images/background/1.webp" class="jarallax-img" alt="">
        <div class="container">
            <div class="row text-light">
                <div class="col-lg-6 offset-lg-3 text-center">                            
                    <div class="subtitle s2 wow fadeInUp mb-3">Our Package</div>
                    <h2 class="wow fadeInUp" data-wow-delay=".2s">Pricing Plans</h2>
                    <div class="spacer-single"></div>
                </div>
            </div>

            <div class="row g-4 align-items-center">
                <div class="col-lg-4 col-sm-6">
                    <div class="relative bg-white h-100 rounded-10px overflow-hidden wow fadeInUp" data-wow-delay=".0s">
                        <h4 class="bg-color text-light p-3">Individual Therapy</h4>
                        <div class="p-3 px-4 mb-4 relative">
                            <img src="images/services/1.webp" class="absolute circle mb-4 w-80px end-0 me-4 shadow-soft wow scaleIn" data-wow-delay=".2s" alt="">
                            <div class="fs-14 text-dark fw-500">Start from</div>
                            <div class="mb-3">
                                <h2 class="d-inline id-color-2">$150</h2><span class="fs-14">/session</span>
                            </div>
                            <p>Dolor laborum ex ut labore officia cupidatat ullamco anim veniam sunt enim aliquip duis dolor anim reprehenderit nulla nostrud.</p>

                            <ul class="ul-style-2 fw-600 text-dark mb-3">
                                <li>Personalized</li>
                                <li>Confidential</li>
                                <li>Effective</li>
                            </ul>

                            <a class="btn-main btn-light-trans w-100" href="appointment.html">
                                Make Appointment
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <div class="relative bg-white h-100 rounded-10px overflow-hidden wow fadeInUp" data-wow-delay=".2s">
                        <h4 class="bg-color-2 text-light p-3">Couples Counseling</h4>
                        <div class="p-3 px-4 mb-4 relative">
                            <img src="images/services/2.webp" class="absolute circle mb-4 w-80px end-0 me-4 shadow-soft wow scaleIn" data-wow-delay=".4s" alt="">
                            <div class="fs-14 text-dark fw-500">Start from</div>
                            <div class="mb-3">
                                <h2 class="d-inline id-color-2">$180</h2><span class="fs-14">/session</span>
                            </div>
                            <p>Dolor laborum ex ut labore officia cupidatat ullamco anim veniam sunt enim aliquip duis dolor anim reprehenderit nulla nostrud.</p>

                            <ul class="ul-style-2 fw-600 text-dark mb-3">
                                <li>Personalized</li>
                                <li>Confidential</li>
                                <li>Effective</li>
                            </ul>

                            <a class="btn-main btn-light-trans w-100" href="appointment.html">
                                Make Appointment
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <div class="relative bg-white h-100 rounded-10px overflow-hidden wow fadeInUp" data-wow-delay=".4s">
                        <h4 class="bg-color text-light p-3">Career Counseling</h4>
                        <div class="p-3 px-4 mb-4 relative">
                            <img src="images/services/3.webp" class="absolute circle mb-4 w-80px end-0 me-4 shadow-soft wow scaleIn" data-wow-delay=".6s" alt="">
                            <div class="fs-14 text-dark fw-500">Start from</div>
                            <div class="mb-3">
                                <h2 class="d-inline id-color-2">$190</h2><span class="fs-14">/session</span>
                            </div>
                            <p>Dolor laborum ex ut labore officia cupidatat ullamco anim veniam sunt enim aliquip duis dolor anim reprehenderit nulla nostrud.</p>

                            <ul class="ul-style-2 fw-600 text-dark mb-3">
                                <li>Personalized</li>
                                <li>Confidential</li>
                                <li>Effective</li>
                            </ul>

                            <a class="btn-main btn-light-trans w-100" href="appointment.html">
                                Make Appointment
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3 text-center">                            
                    <div class="subtitle wow fadeInUp mb-3">Do you have</div>
                    <h2 class="wow fadeInUp" data-wow-delay=".2s">Any Questions</h2>
                </div>
            </div>

            <div class="row g-4 align-items-center">

                <div class="col-lg-12">
                    <div class="accordion s2 wow fadeInUp">
                        <div class="accordion-section">
                            <div class="accordion-section-title" data-tab="#accordion-a1">
                                What kind of therapy services do you offer?
                            </div>
                            <div class="accordion-section-content" id="accordion-a1">
                                <p>We provide a range of therapy services, including individual, couples, and group therapy sessions tailored to your needs.</p>
                            </div>
                            <div class="accordion-section-title" data-tab="#accordion-a2">
                                Do you offer online therapy options?
                            </div>
                            <div class="accordion-section-content" id="accordion-a2">
                                <p>Yes, we offer virtual therapy sessions for your convenience and comfort, ensuring you can access support from anywhere.</p>
                            </div>                                        
                            <div class="accordion-section-title" data-tab="#accordion-a3">
                                How can I schedule an appointment?
                            </div>
                            <div class="accordion-section-content" id="accordion-a3">
                                <p>You can easily schedule an appointment by contacting our office via phone or email, or by filling out our online appointment request form.</p>
                            </div>
                            <div class="accordion-section-title" data-tab="#accordion-a4">
                                Are your services covered by insurance?
                            </div>
                            <div class="accordion-section-content" id="accordion-a4">
                                <p>We accept a variety of insurance plans, and our team can help you navigate the process to ensure you receive the coverage you are entitled to.</p>
                            </div>
                            <div class="accordion-section-title" data-tab="#accordion-a5">
                                Do you offer specialized therapy for specific issues?
                            </div>
                            <div class="accordion-section-content" id="accordion-a5">
                                <p>Our psychologists have expertise in various areas, such as anxiety, depression, trauma, and more, offering specialized therapy tailored to your unique needs.</p>
                            </div>
                            <div class="accordion-section-title" data-tab="#accordion-a6">
                                Can I choose my therapist?
                            </div>
                            <div class="accordion-section-content" id="accordion-a6">
                                <p>We strive to match you with a therapist who best fits your preferences and needs, ensuring a strong therapeutic alliance for effective treatment.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-color no-top no-bottom">
        <div class="container-fluid">
            <div class="row g-0 align-items-center">
                <div class="col-lg-4 col-md-4">
                    <div class="relative p-4 text-light">
                        <i class="d-block fs-40 mb-2 icofont-clock-time"></i>
                        Mon - Sat: 8AM - 9PM<br>
                        Sunday: 10AM - 8PM<br>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4">
                    <div class="relative p-4 bg-color-2 text-light">
                        <i class="d-block fs-40 mb-2 icofont-location-pin"></i>
                        789 Elm Avenue<br>Brooklyn, NY 11201
                    </div>
                </div>

                <div class="col-lg-4 col-md-4">
                    <div class="relative p-4 bg-color-3 text-dark">
                        <i class="d-block fs-40 mb-2 icofont-phone"></i>
                        +929 333 9296<br>
                        contact@mindthera.com
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/front/pages/services.blade.php ENDPATH**/ ?>