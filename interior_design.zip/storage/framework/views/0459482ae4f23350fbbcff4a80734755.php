
<?php $__env->startSection('title'); ?> About us <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="content" class="no-top no-bottom">
    <div id="top"></div>
    <!-- section begin -->
    <section id="de-subheader" class="mt-sm-60 pt20 pb20 bg-gradient-45-deg text-light">
        <div class="container relative z-index-1000">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h3 class="mb-0">About Us</h3>
                </div>

                <div class="col-lg-6 text-lg-end">
                    <ul class="crumb">
                        <li><a href="index.html">Home</a></li>
                        <li class="active">About Us</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- section close -->

    <section>
        <div class="container">
            <div class="row g-4 gx-5 align-items-center">
                <div class="col-lg-6">
                    <div class="relative rounded-20px overflow-hidden shadow-soft">
                        <a class="de-video-play-button popup-youtube" href="http://www.youtube.com/watch?v=RFTUZqXZN6M">
                            <span></span>
                        </a>
                        <img src="images/misc/2.webp" class="img-fluid" alt="">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="subtitle wow fadeInUp mb-3">Who We Are</div>
                    <h2 class="wow fadeInUp">Introducing Our Expert Psychology Professionals</h2>
                    <p class="wow fadeInUp">Located in New York, NY, Mindthera specializes in providing top-notch psychotherapy services. Our team of experienced professionals is dedicated to helping you achieve mental wellness and personal growth. Trust Mindthera for all your psychotherapy needs.</p>
                    <div class="spacer-10"></div>
                    <a class="btn-main wow fadeInUp" href="about.html">About Us</a>
                </div>
            </div>
            
        </div>
    </section>

    <section class="bg-color-2 section-dark text-light text-center pt60 pb50 jarallax">
        <img src="images/background/gradient-3.html" class="jarallax-img" alt="">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-3 col-sm-6 mb-sm-30">
                    <div class="de_count fs-15 wow fadeInRight" data-wow-delay=".0s">
                        <h3 class="fs-40"><span class="timer fs-40" data-to="6250" data-speed="3000">0</span>+</h3>
                        Happy Customers
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-sm-30">
                    <div class="de_count fs-15 wow fadeInRight" data-wow-delay=".2s">
                        <h3 class="fs-40"><span class="timer fs-40" data-to="3200" data-speed="3000">0</span>+</h3>
                        Successfull Therapy
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-sm-30">
                    <div class="de_count fs-15 wow fadeInRight" data-wow-delay=".4s">
                        <h3 class="fs-40"><span class="timer fs-40" data-to="20" data-speed="3000">0</span>+</h3>
                        Years of Exeperience
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-sm-30">
                    <div class="de_count fs-15 wow fadeInRight" data-wow-delay=".6s">
                        <h3 class="fs-40"><span class="timer fs-40" data-to="15" data-speed="3000">0</span>+</h3>
                        Specialist
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="relative jarallax overflow-hidden">
        <img src="images/background/gradient-2.html" class="jarallax-img" alt="">
        <div class="container">
            <div class="row g-4 gx-5">
                <div class="col-lg-12 text-center">
                    <div class="subtitle text-dark wow fadeInUp mb-3">Vision &amp; Mission</div>
                    <h2>Vision &amp; Mission</h2>
                </div>

                <div class="col-lg-6">
                    <h4 class="mb-4 wow fadeInRight">Our Vision</h4>
                    <p class="fs-24 fw-600 lh-1-4 wow fadeInUp">To lead the global automotive industry towards a sustainable future by revolutionizing transportation with innovative electric vehicles, fostering environmental stewardship, and enhancing the quality of life for present and future generations.</p>
                </div>

                <div class="col-lg-6">
                    <h4 class="mb-4 wow fadeInRight">Our Mission</h4>
                    <ol class="ol-style-1">
                        <li class="wow fadeInUp" data-wow-delay=".2s"><span class="fw-bold id-color">Innovation:</span> We strive to push the boundaries of technological advancement, continuously innovating in electric vehicle design, battery technology, and sustainable manufacturing processes.</li>
                        <li class="wow fadeInUp" data-wow-delay=".4s"><span class="fw-bold id-color">Sustainability:</span> Our commitment to sustainability is unwavering. We aim to reduce carbon emissions and minimize environmental impact throughout the entire lifecycle of our products,</li>
                        <li class="wow fadeInUp" data-wow-delay=".6s"><span class="fw-bold id-color">Quality & Safety:</span> The safety and satisfaction of our customers are paramount. We uphold the highest standards of quality, safety, and reliability in every vehicle we produce</li>
                    </ol>
                </div>
            </div>
        </div>

        <img src="images/misc/flowers-crop-4.webp" class="w-20 absolute start-0 bottom-0 sw-anim" alt="">
    </section>

    <section class="bg-color no-top no-bottom">
        <div class="container-fluid">
            <div class="row g-0 align-items-center">
                <div class="col-lg-4 col-md-4">
                    <div class="relative p-4 text-light">
                        <i class="d-block fs-40 mb-2 icofont-clock-time"></i>
                        Mon - Sat: 8AM - 9PM<br>
                        Sunday: 10AM - 8PM<br>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4">
                    <div class="relative p-4 bg-color-2 text-light">
                        <i class="d-block fs-40 mb-2 icofont-location-pin"></i>
                        789 Elm Avenue<br>Brooklyn, NY 11201
                    </div>
                </div>

                <div class="col-lg-4 col-md-4">
                    <div class="relative p-4 bg-color-3 text-dark">
                        <i class="d-block fs-40 mb-2 icofont-phone"></i>
                        +929 333 9296<br>
                        contact@mindthera.com
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/front/pages/abouts.blade.php ENDPATH**/ ?>