
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.frontend.homes.banner-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- end banner section -->

    <?php echo $__env->make('include.frontend.homes.contact-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- end contact section -->

    <?php echo $__env->make('include.frontend.homes.about-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- end about section -->

    <?php echo $__env->make('include.frontend.homes.services-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- end services section -->

    <?php echo $__env->make('include.frontend.homes.counter-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- end customer counter section -->
    
    <?php echo $__env->make('include.frontend.homes.team-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- end team section -->

    <?php echo $__env->make('include.frontend.homes.workprocess-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- end work process section -->
    
    <?php echo $__env->make('include.frontend.homes.case-study-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- end case study section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/pages/frontend/home.blade.php ENDPATH**/ ?>