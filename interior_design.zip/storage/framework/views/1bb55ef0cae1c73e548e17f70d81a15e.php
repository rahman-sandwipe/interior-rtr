<?php
	$settings =App\Models\Settings::find(1);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <meta name="description" content="Smarthr - Bootstrap Admin Template">
		<meta name="keywords" content="admin, estimates, bootstrap, business, corporate, creative, management, minimal, modern, accounts, invoice, html5, responsive, CRM, Projects">
        <meta name="author" content="Dreamguys - Bootstrap Admin Template">
        <meta name="robots" content="noindex, nofollow">
        <title><?php echo $__env->yieldContent('title'); ?> :: <?php echo e(config('app.name')); ?> - </title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset(config('app.logo'))); ?>">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('back/css/bootstrap.min.css')); ?>">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('back/css/font-awesome.min.css')); ?>">
		
		<!-- Lineawesome CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('back/css/line-awesome.min.css')); ?>">
		
		<!-- Chart CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('back/plugins/morris/morris.css')); ?>">

		<!-- Select2 CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('back/css/select2.min.css')); ?>">
		
		<!-- Datatable CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('back/css/dataTables.bootstrap4.min.css')); ?>">

		<!-- Datetimepicker CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('back/css/bootstrap-datetimepicker.min.css')); ?>">
		
		<!-- Tagsinput CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('back/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css')); ?>">

		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('back/css/style.css')); ?>">
		
		<!-- Summernote CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('vendor/summernote/summernote-bs4.css')); ?>">
		<style>
			.image-preview{
				max-width:80px;
				overflow: hidden;
			}
			.image-preview img{
				max-width:80px;
				overflow: hidden;
			}
		</style>
    </head>
	
    <body>
        <div class="main-wrapper">
            <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- /Header -->
			
			<?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- /Sidebar -->
			
			<?php echo $__env->yieldContent('content'); ?>
			<!-- /Page Wrapper -->	
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="<?php echo e(asset('back/js/jquery-3.5.1.min.js')); ?>"></script>
		<!-- Bootstrap Core JS -->
        <script src="<?php echo e(asset('back/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('back/js/bootstrap.min.js')); ?>"></script>
		<!-- Slimscroll JS -->
		<script src="<?php echo e(asset('back/js/jquery.slimscroll.min.js')); ?>"></script>
		<!-- Chart JS -->
		<script src="<?php echo e(asset('back/plugins/morris/morris.min.js')); ?>"></script>
		<script src="<?php echo e(asset('back/plugins/raphael/raphael.min.js')); ?>"></script>
		
		<!-- Select2 JS -->
		<script src="<?php echo e(asset('back/js/select2.min.js')); ?>"></script>
		
		<!-- Summernote JS -->
		<script src="<?php echo e(asset('vendor/summernote/summernote-bs4.js')); ?>"></script>
		<!-- Datetimepicker JS -->
		<script src="<?php echo e(asset('back/js/moment.min.js')); ?>"></script>
		<script src="<?php echo e(asset('back/js/bootstrap-datetimepicker.min.js')); ?>"></script>
		
		<!-- Datatable JS -->
		<script src="<?php echo e(asset('back/js/jquery.dataTables.min.js')); ?>"></script>
		<script src="<?php echo e(asset('back/js/dataTables.bootstrap4.min.js')); ?>"></script>
		
		<!-- Tagsinput JS -->
		<script src="<?php echo e(asset('back/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js')); ?>"></script>
		<!-- Custom JS -->
		<script src="<?php echo e(asset('back/js/app.js')); ?>"></script>
		
		<?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/back/layout.blade.php ENDPATH**/ ?>