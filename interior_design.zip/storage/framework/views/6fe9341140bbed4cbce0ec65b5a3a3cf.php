
<?php $__env->startSection('title'); ?> Services <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <!-- Start Content-->
    <div class="container-fluid">
        <?php echo $__env->make('include.backend.service.page-title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- end page title --> 

        <div class="card-box">
            <div class="card-header">
                <div class="header-title">
                    Service List
                    <!-- Large modal -->
                    <button type="button" class="btn btn-success waves-effect waves-light float-right" data-toggle="modal" data-target=".bs-example-modal-lg">Insert New</button>
                    <?php echo $__env->make('include.backend.service.service-create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- end service create modal -->
                    <!-- /.modal -->
                </div>
            </div>
            
            <?php echo $__env->make('include.backend.service.service-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!-- end content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        // Display img preview
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    var html = '<div class="preview-image border"><img width="100" src="' + e.target.result + '"></div>';
                    $('.preview').append(html);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        // Trigger image preview when file input changes
        $("input[name='img']").change(function() {
            readURL(this);
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/pages/backend/service.blade.php ENDPATH**/ ?>