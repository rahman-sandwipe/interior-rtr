<?php
   $settings=App\Models\Settings::latest()->first();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title><?php echo $__env->yieldContent('title'); ?> :: <?php echo e($settings->Title); ?> - <?php echo e($settings->Tagline); ?></title>
        <link rel="icon" href="<?php echo e(asset($settings->Favicon)); ?>" type="image/gif" sizes="16x16">
        <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
        <meta content="width=device-width, initial-scale=1.0" name="viewport" >
        <meta content="<?php echo e($settings->Tags); ?>" name="keywords" >
        <meta content="<?php echo e($settings->Description); ?>" name="description" >
        <meta content="<?php echo e($settings->Author); ?>" name="author" >
        <meta content="<?php echo e($settings->Developer); ?>" name="developer" >
        <!-- CSS Files
        ================================================== -->
        <link href="<?php echo e(asset('front/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" id="bootstrap">
        <link href="<?php echo e(asset('front/css/plugins.css')); ?>" rel="stylesheet" type="text/css" >
        <link href="<?php echo e(asset('front/css/swiper.css')); ?>" rel="stylesheet" type="text/css" >
        <link href="<?php echo e(asset('front/css/style.css')); ?>" rel="stylesheet" type="text/css" >
        <link href="<?php echo e(asset('front/css/coloring.css')); ?>" rel="stylesheet" type="text/css" >
        <!-- color scheme -->
        <link id="colors" href="<?php echo e(asset('front/css/colors/scheme-01.css')); ?>" rel="stylesheet" type="text/css" >
    </head>

    <body>
        <div id="wrapper">
            <div class="float-text show-on-scroll">
                <span><a href="#">Scroll to top</a></span>
            </div>
            <div class="scrollbar-v show-on-scroll"></div>
            
            <!-- page preloader begin -->
            <div id="de-loader"></div>
            <!-- page preloader close -->

            <!-- header begin -->
           <?php echo $__env->make('front.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- header close -->
            <!-- content begin -->
            <div class="no-bottom no-top" id="content">

                <div id="top"></div>

                <?php echo $__env->yieldContent('content'); ?>

            </div>
            <!-- content close -->
            
            <!-- footer begin -->
            <?php echo $__env->make('front.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        
        <!-- Javascript Files
        ================================================== -->
        <script src="<?php echo e(asset('front/js/plugins.js')); ?>"></script>
        <script src="<?php echo e(asset('front/js/designesia.js')); ?>"></script>
        <script src="<?php echo e(asset('front/js/swiper.js')); ?>"></script>
        <script src="<?php echo e(asset('front/js/custom-marquee.js')); ?>"></script>
        <script src="<?php echo e(asset('front/js/custom-swiper-1.js')); ?>"></script>
    </body>
</html><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/front/layout.blade.php ENDPATH**/ ?>