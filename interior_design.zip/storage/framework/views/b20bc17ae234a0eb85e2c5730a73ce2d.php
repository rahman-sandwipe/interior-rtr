<section class="section-dark text-light text-center jarallax">
    <img src="<?php echo e(asset('images/banners/banner67e112258f823.jpg')); ?>" class="jarallax-img" alt="">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-3 col-sm-6 mb-sm-30">
                <div class="de_count fs-15 wow fadeInRight" data-wow-delay=".0s">
                    <h3 class="fs-40"><span class="timer fs-40" data-to="6250" data-speed="3000">0</span>+</h3>
                    Happy Customers
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-sm-30">
                <div class="de_count fs-15 wow fadeInRight" data-wow-delay=".2s">
                    <h3 class="fs-40"><span class="timer fs-40" data-to="3200" data-speed="3000">0</span>+</h3>
                    Successfull Therapy
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-sm-30">
                <div class="de_count fs-15 wow fadeInRight" data-wow-delay=".4s">
                    <h3 class="fs-40"><span class="timer fs-40" data-to="20" data-speed="3000">0</span>+</h3>
                    Years of Exeperience
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-sm-30">
                <div class="de_count fs-15 wow fadeInRight" data-wow-delay=".6s">
                    <h3 class="fs-40"><span class="timer fs-40" data-to="15" data-speed="3000">0</span>+</h3>
                    Specialist
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/include/frontend/homes/counter-section.blade.php ENDPATH**/ ?>