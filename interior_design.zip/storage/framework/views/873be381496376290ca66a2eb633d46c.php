<div class="table-responsive">
        
    <table class="table table-bordered mb-0">
        <thead>
            <tr>
                <th class="text-center"># / banner ID</th>
                <th class="text-center">Image</th>
                <th class="text-center">Title</th>
                <th class="text-center">Sub Title</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($banners) > 0): ?>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($banner->id); ?> / <?php echo e($banner->bannerID); ?></th>
                    <td><img src="<?php echo e(asset($banner->image)); ?>" alt="<?php echo e($banner->title); ?>" width="100"></td>
                    <td><?php echo e($banner->title); ?></td>
                    <td><?php echo $banner->subtitle; ?></td>
                    <td>
                        <button type="button" class="btn btn-primary waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg-<?php echo e($banner->id); ?>">Edit</button>
                        <a href="<?php echo e(route('banner.destroy', $banner->id)); ?>" class="btn btn-danger waves-effect waves-light mt-1">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td colspan="5" class="text-center">No banners found</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/include/backend/banners/banners.blade.php ENDPATH**/ ?>