<section class="no-top no-bottom">
    <div class="container-fluid">
        <div class="row g-0">
            <div class="col-lg-2 text-center">
                <a href="case-details.html" class="d-block hover">
                    <div class="relative overflow-hidden">
                        <div class="absolute start-0 w-100 abs-middle fs-36 text-white text-center">
                            <i class="icofont-plus hover-scale-in-3"></i>
                        </div>
                        <img src="images/gallery/1.webp" class="img-fluid hover-scale-1-2" alt="">
                    </div>
                </a>
            </div>

            <div class="col-lg-2 text-center">
                <a href="case-details.html" class="d-block hover">
                    <div class="relative overflow-hidden">
                        <div class="absolute start-0 w-100 abs-middle fs-36 text-white text-center">
                            <i class="icofont-plus hover-scale-in-3"></i>
                        </div>
                        <img src="images/gallery/2.webp" class="img-fluid hover-scale-1-2" alt="">
                    </div>
                </a>
            </div>

            <div class="col-lg-2 text-center">
                <a href="case-details.html" class="d-block hover">
                    <div class="relative overflow-hidden">
                        <div class="absolute start-0 w-100 abs-middle fs-36 text-white text-center">
                            <i class="icofont-plus hover-scale-in-3"></i>
                        </div>
                        <img src="images/gallery/3.webp" class="img-fluid hover-scale-1-2" alt="">
                    </div>
                </a>
            </div>

            <div class="col-lg-2 text-center">
                <a href="case-details.html" class="d-block hover">
                    <div class="relative overflow-hidden">
                        <div class="absolute start-0 w-100 abs-middle fs-36 text-white text-center">
                            <i class="icofont-plus hover-scale-in-3"></i>
                        </div>
                        <img src="images/gallery/4.webp" class="img-fluid hover-scale-1-2" alt="">
                    </div>
                </a>
            </div>

            <div class="col-lg-2 text-center">
                <a href="case-details.html" class="d-block hover">
                    <div class="relative overflow-hidden">
                        <div class="absolute start-0 w-100 abs-middle fs-36 text-white text-center">
                            <i class="icofont-plus hover-scale-in-3"></i>
                        </div>
                        <img src="images/gallery/5.webp" class="img-fluid hover-scale-1-2" alt="">
                    </div>
                </a>
            </div>

            <div class="col-lg-2 text-center">
                <a href="case-details.html" class="d-block hover">
                    <div class="relative overflow-hidden">
                        <div class="absolute start-0 w-100 abs-middle fs-36 text-white text-center">
                            <i class="icofont-plus hover-scale-in-3"></i>
                        </div>
                        <img src="images/gallery/6.webp" class="img-fluid hover-scale-1-2" alt="">
                    </div>
                </a>
            </div>
        </div>
    </div>
</section><?php /**PATH H:\LARAVEL_11\interior_design\resources\views/include/frontend/homes/case-study-section.blade.php ENDPATH**/ ?>